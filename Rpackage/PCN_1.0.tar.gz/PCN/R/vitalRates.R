vitalRates=list(
    
    deathE=deathE,
    
    deathJ=deathJ,
    
    growthE=growthE,
    
    growthJ=growthJ,
    
    female.prop=female.prop
    
    )
