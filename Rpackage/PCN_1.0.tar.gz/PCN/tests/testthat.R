library(testthat)
library(PCN)

test_check("PCN")
